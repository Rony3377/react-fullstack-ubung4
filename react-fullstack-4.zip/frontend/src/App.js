import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Menu from './komponente/Menu';
import Startseite from './komponente/Startseite';
import Bestellungen from './komponente/Bestellungen';
import Logout from './komponente/Logout';
import AdminProdukte from "./komponente/AdminProdukte";
import Datenschutz from "./komponente/Datenschutz";
import AdminAngebote from "./komponente/AdminAngebote";
import Anfragen from "./komponente/Anfragen";
import AdminImpressum from "./komponente/AdminImpressum";
import Impressum from "./komponente/Impressum";
import AdminSocialMedia from "./komponente/AdminSocialMedia";
import AdminDatenschutz from "./komponente/AdminDatenschutz";
import Kontakt from "./komponente/Kontakt";
import Warenkorb from "./komponente/Warenkorb";
import Angebote from "./komponente/Angebote";
import Login from "./komponente/Login";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Menu />}>
          <Route path="/" element={
            sessionStorage.getItem("adminStatus") === "1" ?(
              <Bestellungen/>
          ):(
            <Startseite />
            )}  />
          <Route path="/adminprodukte" element={<AdminProdukte />} />
          <Route path="/adminagebote" element={<AdminAngebote/>} />
          <Route path="/anfragen" element={<Anfragen />} />
          <Route path="/adminsocialMedia" element={<AdminSocialMedia />} />
          <Route path="/logout" element={<Logout/>} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Datenschutz/>} />
          <Route path="/adminimpressum" element={<AdminImpressum/>} />
          <Route path="/admindatenschutz" element={<AdminDatenschutz/>} />
          <Route path="/kontakt" element={<Kontakt/>} />
          <Route path="/warenkorb" element={<Warenkorb/>} />
          <Route path="/angebote" element={<Angebote/>} />
          <Route path="/login" element={<Login />} />
          </Route> 
        </Routes>
      </BrowserRouter>
 
    </>
 
  );
}
 
export default App;