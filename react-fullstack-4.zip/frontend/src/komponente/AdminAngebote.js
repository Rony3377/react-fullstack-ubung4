import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";
import { encodeText, decodeText } from "./encodeDecode";

function AngebotsOption({ Daten }) {
  const [produktInfo, produktInfoUpdate] = useState({});
  useEffect(() => {
    produktInfoUpdate(Daten);
  }, [Daten]);

  function notieren(feld) {
    let status = false;
    let neu = [];
    // *** //
    let sammeln =
      sessionStorage.getItem("angebotOptionen") === null ||
      sessionStorage.getItem("angebotOptionen") === ""
        ? []
        : JSON.parse(sessionStorage.getItem("angebotOptionen"));
    // *** //
    if (sammeln.length === 0) {
      if (feld.checked === true) sammeln.push(produktInfo);
    } else {
      for (let x = 0; x < sammeln.length; x++) {
        if (sammeln[x].ProdID === produktInfo.ProdID) {
          if (feld.checked === true) status = true;
          else if (feld.checked === false) {
            sammeln[x] = 0;
            status = true;
          }
        }
      }
      // *** //
      if (status === false && feld.checked === true) sammeln.push(produktInfo);
      // *** //
      if (sammeln.length > 0) {
        for (let x of sammeln) {
          if (typeof x === "object") neu.push(x);
        }
        // *** //
        sammeln = neu;
      }
    }
    // *** //
    sessionStorage.setItem("angebotOptionen", JSON.stringify(sammeln));
  }

  return (
    <>
      <input
        type="checkbox"
        onChange={(e) => notieren(e.target)}
        onMouseDown={(e) => notieren(e.target)}
        onMouseUp={(e) => notieren(e.target)}
      />
      {Daten.Produktname} (Normalpreis: {Daten.Preis})
      <br />
    </>
  );
}

function AngebotDetailInfo({ Daten }) {
  const [inhalt, inhaltNeu] = useState([]);
  useEffect(() => 
  {
    const x = [];
    let D = decodeText(Daten);
    let datenWert = "[";
    for(let c = 1; c < D.length;c++)
    {
      datenWert += D[c];
    }

    // *** //
    D = JSON.parse(datenWert);
    //console.log(typeof D, JSON.parse(datenWert), datenWert, decodeText(datenWert));
    // *** //
    if (typeof D === "object")
      D.forEach((e) => {
        x.push(
          <li>
            <td>{e.Produktname}</td>
          </li>
        );
      });
    // *** //
    inhaltNeu(<ul>{x}</ul>);
  }, [Daten]);
  return <>{inhalt}</>;
}

export default function AdminAngebote() {
  const [angebote, setAngebote] = useState([]);
  const [adminStatus, adminStatusUpdate] = useState(false);
  const [produkte, produkteUpadte] = useState([]);
  const [titel, titelUpdate] = useState("");
  const [preis, preisUpdate] = useState("");
  const [daten, dateneUpadte] = useState("");

  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));
  }
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));
  }
  function angeboteLaden() {
    readJSONFromServer(
      "http://localhost:8087/abruf/angebot/tabelle",
      (antwort) => {
        const angeboteElements = [];
        for (let a of antwort) {
          angeboteElements.push(
            <tr key={a.AngID}>
              <td>
                <p>{a.Angebotsname}</p>
              </td>
              <td>
                <p>{a.Preis}</p>
              </td>
              <td>
                <p>
                  <AngebotDetailInfo Daten={a.Daten} />
                </p>
              </td>
              <td>
                <button onClick={() => handleEntfernenClick(a.AngID)}>
                  Entfernen
                </button>
              </td>
            </tr>
          );
        }
        //
        setAngebote(angeboteElements);
      }
    );
  }

  function produkteNeuLaden() {
    readJSONFromServer(
      "http://localhost:8087/abruf/produkt/tabelle",
      (antwort) => {
        const neu = [];
        // *** //
        antwort.forEach((eintrag) => {
          neu.push(<AngebotsOption Daten={eintrag} />);
        });
        // *** //
        produkteUpadte(neu);
      }
    );
  }

  useEffect(() => {
    const a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    // *** //
    produkteNeuLaden();
    // *** //
    angeboteLaden();
  }, [angeboteLaden]);

  function hinzufugen() {
    if (titel.value === undefined) {
      alert("Bitte Angebotsname angeben!");
      return;
    }
    if (preis.value === undefined) {
      alert("Bitte Preis angeben!");
      return;
    }

    //    dateneUpadte(sessionStorage.getItem("angebotOptionen"));
    let DatenVonAngebot = sessionStorage.getItem("angebotOptionen");

    if (
      DatenVonAngebot === "" ||
      DatenVonAngebot === undefined ||
      DatenVonAngebot === null
    ) {
      alert("Daten müssen erneut ausgewählt werden");
      sessionStorage.removeItem("angebotOptionen");
      produkteUpadte([]);
      produkteNeuLaden();
      return;
    }
   // console.log("Hinzugefügt...",DatenVonAngebot,JSON.parse(DatenVonAngebot),encodeText(DatenVonAngebot))
    //alert(titel.value+"\n"+preis.value+"\n"+sessionStorage.getItem("angebotOptionen")+"\n\n"+daten);
    readTEXTFromServer(
      "http://localhost:8087/admin/angebot/neu/" +
        titel.value +
        "/" +
        preis.value +
        "/" +
        encodeText(DatenVonAngebot),

      (e) => {
        titel.value = "";
        preis.value = "";

        titelUpdate("");

        preisUpdate("");

        dateneUpadte("");

        angeboteLaden();

        sessionStorage.removeItem("angebotOptionen");

        produkteUpadte([]);
        produkteNeuLaden();
      }
    );
  }

  const handleEntfernenClick = (id) => {
    readTEXTFromServer(
      "http://localhost:8087/admin/angebot/entf/" + id,
      (antwort) => {
        angeboteLaden();
        alert("Produkt wurde entfernt! ");
      }
    );
  };
  return (
    <>
      {adminStatus === false ? (
        <ZugriffVerweigert />
      ) : (
        <div>
          <h3>Admin Angebote</h3>
          <table>
            <thead>
              <tr>
                <th>Angebot</th>
                <th>Aktionen</th>
              </tr>
            </thead>
            <tbody>{angebote}</tbody>
          </table>
          <hr />
          <input
            type="text"
            placeholder="Angebotsname..."
            onKeyUp={(e) => titelUpdate(e.target)}
          />
          <br />
          <input
            type="number"
            placeholder="Angebotspreis..."
            onKeyUp={(e) => preisUpdate(e.target)}
          />
          <br />
          <h4>Welche Produkte gehören zum Angebot?</h4>
          {produkte}
          <button onClick={() => hinzufugen()}> Angebot erstellen</button>
        </div>
      )}
    </>
  );
}
