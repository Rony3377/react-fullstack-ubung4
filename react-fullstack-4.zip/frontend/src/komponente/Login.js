import React, { useState } from "react";

export default function Login() {
  const [benutzer, benutzerNeu] = useState("");
  const [kennwort, kennwortNeu] = useState("");
  const [fehler, fehlerNeu] = useState("");

  // *** //

  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken
    window
      .fetch(u)
      // Antwort erhalten und als Text weiterreichen
      .then((rohdaten) => rohdaten.text())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }

  function loginJetzt() {
    readTEXTFromServer(
      "http://localhost:8087/login/" + benutzer + "/" + kennwort,

      (antwort) => {
        sessionStorage.setItem("adminStatus", antwort);
//alert("ok\n"+antwort);
        if (antwort == "1") window.location.href = "http://localhost:3000/";
        else
          fehlerNeu(
            <div>
              <b>Benutzername oder Kennwort falsch!</b>
              <hr />
            </div>
          );
      }
    );
  }

  return (
    <>
      <div
        style={{
          width: "200px",
          marginLeft: "auto",
          marginRight: "auto",
          marginBottom: "40px"
        }}
      >
        {fehler}
        <input
          type="text"
          placeholder="Benutzer..."
          onKeyUp={(e) => benutzerNeu(e.target.value)}
        />
        <br />
        <input
          type="password"
          placeholder="Kennwort..."
          onKeyUp={(e) => kennwortNeu(e.target.value)}
        />
        <br />
        <button onClick={() => loginJetzt()}>Anmelden</button>
      </div>
    </>
  );
}
