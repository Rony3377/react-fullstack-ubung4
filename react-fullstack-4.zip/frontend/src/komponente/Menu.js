import { Link, Outlet } from "react-router-dom";
import React, { useEffect, useState } from "react";
import "./Menu.css";

export default function Menu() {
  const [adminStatus, adminStatusUpdate] = useState(false);
  const [facebook, facebookUpdate] = useState("");
  const [twitter, twitterUpdate] = useState("");
  const [linkedin, linkedinUpdate] = useState("");
  const [instagram, instagramUpdate] = useState("");
  const [logo, logoUpdate] = useState("");

  useEffect(() => {
    let a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
  }, []);

  return (
    <>
      {adminStatus === false ? (
        <header>
          <ul style={{ justifyContent: "space-between", fontSize: "20px" }}>
            <li>
              <a href={logo} target="_blank">
                <img src="l.png" alt="logo" style={{ width: "50px" }} />
              </a>
            </li>
            <li>
              <Link to="/">Starseite</Link>
            </li>
            <li>
              <Link to="/Angebote">Angebote</Link>
            </li>
            <li>
              <Link to="/warenkorb">Warenkorb</Link>
            </li>
          </ul>
        </header>
      ) : (
        <header>
          <ul>
            <li>
              <a href={logo} target="_blank">
                <img src="l.png" alt="logo" />
              </a>
            </li>
            <li>
              <Link to="/">Bestellungen</Link>
            </li>
            <li>
              <Link to="/AdminProdukte">Produkte</Link>
            </li>
            <li>
              <Link to="/adminagebote">Angebote</Link>
            </li>
            <li>
              <Link to="/Anfragen">Anfragen</Link>
            </li>
            <li>
              <Link to="/AdminSocialMedia">SocialMedia</Link>
            </li>
            <li>
              <b>
                <Link to="/logout">Abmelden</Link>
              </b>
            </li>
          </ul>
        </header>
      )}
      <main>
        <Outlet />
      </main>
      {adminStatus === false ? (
        <footer>
          <div>
            <a href={twitter} target="_blank">
              <img src="x.png" alt="twitter" />
            </a>
            <a href={facebook} target="_blank">
              <img src="f.png" alt="facebook" />
            </a>
            <a href={instagram} target="_blank">
              <img src="inst.png" alt="instagram" />
            </a>
            <a href={linkedin} target="_blank">
              <img src="link.png" alt="linkedin" />
            </a>
          </div>
          <div>
            <Link to="/Kontakt">
              <b>Kontakt</b>
            </Link>
            <Link to="/Impressum">
              <b>Impressum</b>
            </Link>
            <Link to="/Datenschutz">
              <b>Datenschutz</b>
            </Link>
          </div>
        </footer>
      ) : (
        <footer>
          <div>
            <Link to="/AdminImpressum">Impressum</Link>
            <Link to="/AdminDatenschutz">Datenschutz</Link>
          </div>

          <div>
            <a href={twitter} target="_blank">
              <img src="x.png" alt="twitter" />
            </a>
            <a href={facebook} target="_blank">
              <img src="f.png" alt="facebook" />
            </a>
            <a href={instagram} target="_blank">
              <img src="inst.png" alt="instagram" />
            </a>
            <a href={linkedin} target="_blank">
              <img src="link.png" alt="linkedin" />
            </a>
          </div>
        </footer>
      )}
    </>
  );
}
