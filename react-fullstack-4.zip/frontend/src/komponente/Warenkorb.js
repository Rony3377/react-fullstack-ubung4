import React, { useState, useEffect } from "react";
import {encodeText} from "./encodeDecode";

function WarenkorbEintrag({ Daten, Funk }) {
  const [menge, mengeNeu] = useState(Daten.Menge);

  function aendern(neueMenge, preis, name, typ, id) {
    let korb = JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    for (let e = 0; e < korb.length; e++) {
      if (korb[e].Typ == typ && korb[e].ID == id) {
        korb[e] = {
          ID: id,
          Menge: neueMenge,
          Name: name,
          Preis: preis,
          Typ: typ,
        };
        // *** //
        break;
      }
    }
    // *** //
    mengeNeu(neueMenge);
    // *** //
    sessionStorage.setItem("WKJSON", JSON.stringify(korb));
    // *** //
    Funk();
  }

  function entfernen(typ, id) {
    let korb = JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    let neu = [];
    // *** //
    for (let e = 0; e < korb.length; e++) {
      if (korb[e].Typ == typ && korb[e].ID != id) neu.push(korb[e]);
      else if (korb[e].Typ != typ) neu.push(korb[e]);
    }
    // *** //
    sessionStorage.setItem("WKJSON", JSON.stringify(neu));
    // *** //
    Funk();
  }

  return (
    <tr>
      <td>{Daten.Name}</td>
      <td>{Daten.Preis}</td>
      <td>
        <input
          type="number"
          defaultValue={Daten.Menge}
          onKeyUp={(e) =>
            aendern(
              e.target.value,
              Daten.Preis,
              Daten.Name,
              Daten.Typ,
              Daten.ID
            )
          }
          onChange={(e) =>
            aendern(
              e.target.value,
              Daten.Preis,
              Daten.Name,
              Daten.Typ,
              Daten.ID
            )
          }
          onMouseDown={(e) =>
            aendern(
              e.target.value,
              Daten.Preis,
              Daten.Name,
              Daten.Typ,
              Daten.ID
            )
          }
          onMouseUp={(e) =>
            aendern(
              e.target.value,
              Daten.Preis,
              Daten.Name,
              Daten.Typ,
              Daten.ID
            )
          }
        />
      </td>
      <td>
        <button onClick={() => entfernen(Daten.Typ, Daten.ID)}>
          Entfernen
        </button>
      </td>
    </tr>
  );
}

export default function Warenkorb() {
  const [warenkorb, setWarenkorb] = useState([]);

  const [gesamt, gesamtNeu] = useState(0);
  const [netto, nettoNeu] = useState(0);
  const [steuer, steuerNeu] = useState(0);

  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));
  }

  function bestellen() {
    let daten = sessionStorage.getItem("WKJSON");
    // *** //
    if(daten != null && daten != "")
    {
        daten = encodeText(daten);
        // *** //
        let kosten = {
            brutto: gesamt,
            netto: netto,
            mwst: steuer,
          };
          readTEXTFromServer(
            "http://localhost:8087/warenkorb/neu/" + daten + "/" + JSON.stringify(kosten),
            (e) => {
              sessionStorage.removeItem("WKJSON");
              setWarenkorb([]);
              gesamtNeu(0);
              nettoNeu(0);
              steuerNeu(0);
            }
          );      
    }
  }

  function leermachen() {
    sessionStorage.removeItem("WKJSON");
    setWarenkorb([]);
    gesamtNeu(0);
    nettoNeu(0);
    steuerNeu(0);
  }

  function aktualisieren() {
    let korb =
      sessionStorage.getItem("WKJSON") == "" ||
      sessionStorage.getItem("WKJSON") == null
        ? []
        : JSON.parse(sessionStorage.getItem("WKJSON"));
    // *** //
    const code = [];
    // *** //
    let bruttoWert = 0;
    let steuerWert = 0;
    let nettoWert = 0;
    // *** //
    korb.forEach((eintrag) => {
      code.push(
        <WarenkorbEintrag Daten={eintrag} Funk={() => aktualisieren()} />
      );
      // *** //
      bruttoWert += eintrag.Menge * eintrag.Preis;
    });
    // *** //
    steuerWert = (7 / 100) * bruttoWert;
    nettoWert = bruttoWert - steuerWert;
    // *** //
    gesamtNeu(bruttoWert);
    steuerNeu(steuerWert);
    nettoNeu(nettoWert);
    // *** //
    setWarenkorb(code);
  }

  useEffect(() => {
    aktualisieren();
  }, []);

  return (
    <div>
      <h3>Bestellliste</h3>
      <table>
        <tr>
          <th>Produkt</th>
          <th>Preis</th>
          <th>Menge</th>
          <th>Aktion</th>
        </tr>
        {warenkorb}
      </table>
      <p>Gesamtbetrag: {gesamt.toFixed(2)}€</p>
      <p>MwSt: {steuer.toFixed(2)}€</p>
      <p>Nettobetrag: {netto.toFixed(2)}€</p>
      <button onClick={() => bestellen()}>Bestellen</button>
      <button onClick={() => leermachen()}>Warenkorb leeren</button>
    </div>
  );
}
