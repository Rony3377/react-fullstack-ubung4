import React, {useEffect} from "react";

export default function Logout()
{
    useEffect(
        () => {
            sessionStorage.removeItem("adminStatus");
            sessionStorage.removeItem("WKJSON");
            // *** //
            window.setTimeout(
                ()=>
                {
                    window.location.href="http://localhost:3000/";
                },
                1000
            );
        }
    );
    return <>Du bist ausgeloggt...</>;
}