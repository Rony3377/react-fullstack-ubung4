import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";
 
export default function AdminDatenschutz() {
 
  const [adminStatus, adminStatusUpdate] =useState(false);
  const [datenschutzText, setDatenschutzText] = useState('');
  const [state, setState] = useState(false);
    //
    function readJSONFromServer(u, cb) {
      // Anfrage an den Server scihcken
   
      window
   
        .fetch(u)
   
        // Antwort erhalten und als JSON-Objekt weiterreichen
   
        .then((rohdaten) => rohdaten.json())
   
        // Die weitergereichte Information an die Callback-Funktion übergeben
   
        .then((daten) => cb(daten))
   
        // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
   
        .catch((fehler) => console.error(fehler));
    }
 
 
  function readTEXTFromServer(u, cb) {
 
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als Text weiterreichen
 
      .then((rohdaten) => rohdaten.text())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
 
  }
 
 
  useEffect(() => {
    const a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    //
    readTEXTFromServer("http://localhost:8087/admin/datenschutz/lesen/", (antwort)=>setDatenschutzText(antwort));
   
 
  }, []);
 
  function speichern() {
 
    readTEXTFromServer("http://localhost:8087/admin/aendern/d/" + datenschutzText ,
      (antwort) => {
        let r=datenschutzText;
        if(r)
        readTEXTFromServer(datenschutzText, (antwort) => {
          setState(true);
       } );
      });
  }
    return (
      <>
  {adminStatus === false ?
  (<ZugriffVerweigert />):(
    <>
    <textarea
     placeholder="Datenschutz ..."
     defaultValue={datenschutzText}
     onKeyUp={e => setDatenschutzText(e.target.value)}
    />
    <button onClick={() => speichern()}>Ändern</button>
  </>
  )}
 
  {state && <p>Aktualisierung erfolgreich!</p>}
 </>
 
    );
  }