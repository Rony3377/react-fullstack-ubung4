import React, { useState, useEffect } from "react";
export default function ProduktAngebotzeile({ Daten }) {
  const [gesamt, gesamtUpdate] = useState(0);
  const [menge, mengeUpdate] = useState(0);
  const [preis, preisUpdate] = useState(0);
  const [type, typeUpdate] = useState("");
  const [name, nameUpdate] = useState("");
  const [id, idUpdate] = useState(undefined);
  const [daten, datenUpdate] = useState("");

  function neuBerechnen(feld) {
    // Die aktuelle Menge des Produkts wird aktualisiert
    mengeUpdate(feld.value);

    // Der Gesamtwert des Produktkaufs wird auch aktualisiert
    gesamtUpdate(Number(preis) * Number(menge));

    // Der vorübergehende Key aus dem SessionStorage wird ausgelesen
    // und in ein Array-Objekt konvertiert
    let objekt =
      sessionStorage.getItem("vorbereiten") === "" ||
      sessionStorage.getItem("vorbereiten") === null
        ? []
        : JSON.parse(sessionStorage.getItem("vorbereiten"));

    // Wenn das Array leer ist ...
    if (objekt.length === 0) {
      // Wird einfach ein neuer JSON hinzugefügt
      objekt.push({
        Typ: type,
        Name: name,
        Preis: preis,
        Menge: menge,
        ID: id,
      });
    // Wenn das Array nicht leer ist ...
    } else if (objekt.length > 0) {
      // Dann notieren wird uns eine Statusvariable ...
      let status = false;
      // *** //
      // und Laufen das Array-Objekt durch...
      for (let x = 0; x < objekt.length; x++) {
        // Falls im Array bereits ein JSON enthalten ist,
        // dass denselben TYP und ID hat, dann ...
        if (objekt[x].Typ === type && objekt[x].ID === id) {
          // Überschreiben wir den JSON mit dem aktuellen Wert ...
          objekt[x] = {
            Typ: type,
            Name: name,
            Preis: preis,
            Menge: menge,
            ID: id,
          };
          // *** //
          // und der Status wird auf true gesetzt, weil das Objekt
          // schon im Array vorhanden ist
          status = true;
          // *** //
          // und die Schleife wird verlassen...
          break;
        }
      }
      // *** //
      // Falls der Status immer noch bei false ist, ...
      if (status === false)
      // dann muss wieder ein neuer JSON hinzugefügt werden
        objekt.push({
          Typ: type,
          Name: name,
          Preis: preis,
          Menge: menge,
          ID: id,
        });
    }

    // Zum Schluss wird der KEY im SessionStoragen mit dem
    // neuen ARRAY aktualisiert
    sessionStorage.setItem("vorbereiten", JSON.stringify(objekt));
  }
  useEffect(() => {
    mengeUpdate(0);
    preisUpdate(Daten.Preis);
    gesamtUpdate(Number(preis) * Number(menge));
    // *** //
    if (Daten.ProdID !== undefined) {
      typeUpdate("P");
      idUpdate(Daten.ProdID);
      nameUpdate(Daten.Produktname);
      datenUpdate("");
    } else {
      typeUpdate("A");
      idUpdate(Daten.AngID);
      nameUpdate(Daten.Angebotsname);
      datenUpdate(Daten.Daten);
    }
  }, [Daten]);
  return (
    <tr>
      <td>
        <p>
          <b>{type === "P" ? Daten.Produktname : Daten.Angebotsname}</b>
        </p>
      </td>
      <td>
        <input
          type="number"
          placeholder="Menge...."
          defaultValue={menge}
          onKeyUp={(e) => {
            neuBerechnen(e.target);
          }}
          onChange={(e) => {
            neuBerechnen(e.target);
          }}
          onMouseDown={(e) => {
            neuBerechnen(e.target);
          }}
          onMouseUp={(e) => {
            neuBerechnen(e.target);
          }}
        />
      </td>
      <td>
        <p>
          <u>{preis}€</u>
        </p>
      </td>
      <td>
        <p>
          <u>{gesamt}€</u>
        </p>
      </td>
    </tr>
  );
}
