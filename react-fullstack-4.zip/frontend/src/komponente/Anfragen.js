import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";
import { encodeText, decodeText } from "./encodeDecode";
 
function KontaktDaten({ Daten }) {
  const [kontaktInfo, kontaktInfoUpdate] = useState({});
  useEffect(() => {
    kontaktInfoUpdate(Daten);
  }, [Daten]);
 
  return (
    <>
      <tr>
     <td> {Daten.Vorname}</td>
     <td> {Daten.Nachname}</td>
     <td> {Daten.Telefon}</td>
     <td> {Daten.Email}</td>
     
     </tr>
     <h3> Nachricht</h3>
     <p> {Daten.Nachricht}</p>
     
    </>
  );
}
 
 
export default function Anfragen() {
  const [anfragen, setAnfragen] = useState([]);
  const [adminStatus, adminStatusUpdate] = useState(false);
  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als Text weiterreichen
 
      .then((rohdaten) => rohdaten.text())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als JSON-Objekt weiterreichen
 
      .then((rohdaten) => rohdaten.json())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
   
  function kontaktLaden() {
    readJSONFromServer(
      "http://localhost:8087/admin/kontakt/abruf",
      (zeilen) => {
       //
       if(typeof zeilen === "object" && zeilen.length > 0)
       {
         const htmlCode = [];
 
         // *** //
         zeilen.forEach((zeile) => {
           htmlCode.push(
             <>
               <KontaktDaten Daten={zeile} />
             
       <button onClick={() => deleteKontaktAnfrage(zeile.KAID)}>
         Löschen
       </button>
       <hr />
             </>
           );
         });
 
         // *** //
 
         setAnfragen(htmlCode);  
       }
     
 
      }
    );
  }
 
    useEffect(() => {
      const a = sessionStorage.getItem("adminStatus");
      adminStatusUpdate(a === "1" ? true : false);
   
      // *** //
      kontaktLaden();
    }, []);
 
    const deleteKontaktAnfrage = (id) =>{
      readTEXTFromServer(
        "http://localhost:8087/admin/kontaktt/entf/" + id,
        (antwort) => {
          kontaktLaden();
          alert("kontakt wurde entfernt! ");
        }
      );
     }
    return (
      <>
      {adminStatus === false ? (
        <ZugriffVerweigert />
      ) :
      (<div>
      <table>
       
          <tr>
            <th>Vorname</th>
            <th>Nachname</th>
            <th>Telefon</th>
            <th>Email</th>
           
     
           
          </tr>
       
       
      {anfragen}
       
      </table>
     
     
    </div>)}
    </>
 
    );
  }