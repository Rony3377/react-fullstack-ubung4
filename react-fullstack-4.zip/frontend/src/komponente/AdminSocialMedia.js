import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";
 
export default function AdminSocialMedia() {
  const [adminStatus, adminStatusUpdate] = useState(false);
  const [stateVonF, stateVonFUpdate] = useState("");
  const [stateVonX, stateVonXUpdate] = useState("");
  const [stateVonG, stateVonGUpdate] = useState("");
  const [stateVonL, stateVonLUpdate] = useState("");
  const [state, setState] = useState(false);
 
 
 
  useEffect(() => {
    const a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    //
    readTEXTFromServer("http://localhost:8087/admin/socialMedia/lesen/X", (antwort)=>stateVonXUpdate(antwort));
    readTEXTFromServer("http://localhost:8087/admin/socialMedia/lesen/F", (antwort)=>stateVonFUpdate(antwort));
    readTEXTFromServer("http://localhost:8087/admin/socialMedia/lesen/G", (antwort)=>stateVonGUpdate(antwort));
    readTEXTFromServer("http://localhost:8087/admin/socialMedia/lesen/L", (antwort)=>stateVonLUpdate(antwort));
  }, []);
 
  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als Text weiterreichen
 
      .then((rohdaten) => rohdaten.text())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
  function socialMediaAktualisieren(welche) {
    let route = "";
    route =
      welche === "X"
        ? "http://localhost:8087/admin/socialMedia/aendern/" +
        "X" +
        "/" +
        stateVonX
        : welche === "F"
          ? "http://localhost:8087/admin/socialMedia/aendern/" +
          "F" +
          "/" +
          stateVonF
          : welche === "G"
            ? "http://localhost:8087/admin/socialMedia/aendern/" +
            "G" +
            "/" +
            stateVonG
            : "http://localhost:8087/admin/socialMedia/aendern/" +
            "L" +
            "/" +
            stateVonL;
            if(route)
    readTEXTFromServer(route, (antwort) => {
      setState(true);
   }
   
   
 
   );
  }
  return (
    <>
      {adminStatus === false ?
        (<ZugriffVerweigert />) : (
          <>
            <input type="text"
              placeholder="X ..."
              defaultValue={stateVonX}
              onKeyUp={(e) => stateVonXUpdate(e.target.value)} />
            <button onClick={() => socialMediaAktualisieren("X")}>X Ändern</button>
            <hr />
            <input type="text"
              placeholder="Facebook ..."
              defaultValue={stateVonF}
              onKeyUp={(e) => stateVonFUpdate(e.target.value)} />
            <button onClick={() => socialMediaAktualisieren("F")}>Facebook Ändern</button>
            <hr />
            <input type="text"
              placeholder="Instagram ..."
              defaultValue={stateVonG}
              onKeyUp={(e) => stateVonGUpdate(e.target.value)} />
            <button onClick={() => socialMediaAktualisieren("G")}>Instagram Ändern</button>
            <hr />
            <input type="text"
              placeholder="LinkedIn ..."
              defaultValue={stateVonL}
              onKeyUp={(e) => stateVonLUpdate(e.target.value)} />
            <button onClick={() => socialMediaAktualisieren("L")}>LinkedIn Ändern</button>
            <hr />
 
          </>
        )}
        {state}
    </>
  );
}