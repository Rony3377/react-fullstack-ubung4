import React, { useEffect, useState } from "react";
import ZugriffVerweigert from "./ZugriffVerweigert";
import BestellungDetails from "./BestellungDetails";

export default function Bestellungen() {
  const [adminStatus, adminStatusUpdate] = useState(false);
  const [bestellung, bestellungUpdate] = useState("");

  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));
  }
  function produkteLaden() {
    readJSONFromServer(
      "http://localhost:8087/bestellungen",
      (antwort) => {
        if (typeof antwort === "object" && antwort.length > 0) {
          const daten = [];
          antwort.forEach((zeile) => {
            daten.push(
              <>
                <BestellungDetails Daten = {zeile} />
              </>
            );
          });
          bestellungUpdate(daten);
        }
      }
    );
  }

  function details(bestNr) {}
  useEffect(() => {
    let a = sessionStorage.getItem("adminStatus");
    adminStatusUpdate(a === "1" ? true : false);
    produkteLaden();
  }, []);

  return (
    <>
      {adminStatus === true ? (
        <>
        <div>
          <table>
            <tr>
              <th>Bestellnummer</th>
              <th>Datum</th>
              <th>Endpreis</th>
              <th></th>
            </tr>
            {bestellung}
          </table>
        </div>
      </>
      ) : (
        <ZugriffVerweigert />
        )}
    </>
  );
}
