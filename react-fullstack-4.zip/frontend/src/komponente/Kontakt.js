import React, { useState } from "react";

export default function Kontakt() {
  const [vorname, vornameUpdate] = useState("");
  const [nachname, nachnameUpdate] = useState("");
  const [email, emailUpdate] = useState("");
  const [telefon, telefonUpdate] = useState("");
  const [nachricht, nachrichtUpdate] = useState("");

  function readTEXTFromServer(u, cb) {
    // Anfrage an den Server scihcken
    window
      .fetch(u)
      // Antwort erhalten und als Text weiterreichen
      .then((rohdaten) => rohdaten.text())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken
    window
      .fetch(u)
      // Antwort erhalten und als JSON-Objekt weiterreichen
      .then((rohdaten) => rohdaten.json())
      // Die weitergereichte Information an die Callback-Funktion übergeben
      .then((daten) => cb(daten))
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
      .catch((fehler) => console.error(fehler));
  }

  function senden() {
    const objekt = {
      Vorname: vorname.value,
      Nachname: nachname.value,
      Email: email.value,
      Telefon: telefon.value,
      Nachricht: nachricht.value
    };
    // *** //
    readTEXTFromServer(
      "http://localhost:8087/ablegen/kontakt/" + JSON.stringify(objekt),
      (antwort) => {
        vorname.value = "";
        nachname.value = "";
        email.value = "";
        telefon.value = "";
        nachricht.value = "";
      }
    );
  }

  return (
    <>
      <div style={{ marginLeft: "20%", width: "300px" }}>
        <input
          type="text"
          placeholder="Vorname..."
          onKeyUp={(e) => vornameUpdate(e.target)}
        />
        <input
          type="text"
          placeholder="Nachname..."
          onKeyUp={(e) => nachnameUpdate(e.target)}
        />
        <input
          type="number"
          placeholder="Telefon..."
          onKeyUp={(e) => telefonUpdate(e.target)}
        />
        <input
          type="text"
          placeholder="Email..."
          onKeyUp={(e) => emailUpdate(e.target)}
        />
        <textarea
          placeholder="Nachricht..."
          onKeyUp={(e) => nachrichtUpdate(e.target)}
        ></textarea>
        <button style={{ marginLeft: "25%" }} onClick={() => senden()}>
          senden
        </button>

        <hr />
      </div>
    </>
  );
}
