import React, { useEffect, useState } from "react";
import ProduktAngebotzeile from "./ProduktAngebotzeile";
 
export default function Angebote() {
  const [angebot, angebotUpdate] = useState([]);
 
  function readJSONFromServer(u, cb) {
    // Anfrage an den Server scihcken
 
    window
 
      .fetch(u)
 
      // Antwort erhalten und als JSON-Objekt weiterreichen
 
      .then((rohdaten) => rohdaten.json())
 
      // Die weitergereichte Information an die Callback-Funktion übergeben
 
      .then((daten) => cb(daten))
 
      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
 
      .catch((fehler) => console.error(fehler));
  }
 
  function aktualisiereInhalt() {
    readJSONFromServer(
      "http://localhost:8087/abruf/angebot/tabelle",
      (zeilen) => {
        if(typeof zeilen === "object" && zeilen.length > 0)
        {
          const htmlCode = [];
 
          // *** //
          zeilen.forEach((zeile) => {
            htmlCode.push(
              <>
                <ProduktAngebotzeile Daten={zeile} />
              </>
            );
          });
 
          // *** //
 
          angebotUpdate(htmlCode);  
        }
      }
    );
  }
 
  useEffect(() => {
    aktualisiereInhalt();
  }, []);
 
  function zumWarenkorbHinzufuegen(){
   
    sessionStorage.setItem("WKJSON", sessionStorage.getItem("vorbereiten"));
    sessionStorage.removeItem("vorbereitens");
  }
 
  return (
    <>
      <h3>Angebote</h3>
      <table>
        <tr>
          <th>Produkt</th>
          <th>Menge</th>
          <th>Stückpreis</th>
          <th>Gesamtpreis</th>
          <th></th>
        </tr>
        {angebot}
      </table>
      <hr />
      <button onClick={()=>zumWarenkorbHinzufuegen()}>+</button>
    </>
  );
}